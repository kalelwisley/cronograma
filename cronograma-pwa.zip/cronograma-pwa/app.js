(function () {
  "use strict";

  var STORAGE_CUSTOM = "cronograma:custom-tasks";
  var STORAGE_COMPLETED_PREFIX = "cronograma:completed:";

  var DEFAULT_BLOCKS = [
    {
      id: "casa-manha",
      time: "06:00 – 12:30",
      title: "Casa & Estudo",
      subtitle: "Horário de pico — tarefas mais fáceis, rotina de casa",
      icon: "🏠",
      color: "#7C9885",
      tasks: [
        { id: "t-acordar", label: "Acordar, água, alongamento leve" },
        { id: "t-afazeres", label: "Organizar a casa / afazeres domésticos" },
        { id: "t-idioma", label: "Estudo de idioma (áudio/podcast durante as tarefas)" },
        { id: "t-irmao", label: "Buscar o irmão na escola" },
        { id: "t-almoco-pronto", label: "Deixar o almoço pronto até 12h30" }
      ]
    },
    {
      id: "almoco",
      time: "12:30 – 13:35",
      title: "Almoço",
      subtitle: "Comer com calma antes do deslocamento",
      icon: "🍽️",
      color: "#A9B3AC",
      tasks: [
        { id: "t-almocar", label: "Almoçar com a família" },
        { id: "t-preparar-saida", label: "Separar o que precisa levar pro escritório" }
      ]
    },
    {
      id: "escritorio",
      time: "13:35 – 18:25",
      title: "Escritório (Advocacia)",
      subtitle: "13:35 sai a pé · 14h–18h expediente · 18h caminha de volta",
      icon: "💼",
      color: "#E8A33D",
      tasks: [
        { id: "t-caminhada-ida", label: "Caminhada até o escritório (25 min)" },
        { id: "t-pendencias", label: "Checar prazos e perícias em aberto" },
        { id: "t-processos", label: "Acompanhar casos / organizar documentos" },
        { id: "t-gestao", label: "Revisão geral: o que precisa da sua atenção hoje" },
        { id: "t-caminhada-volta", label: "Caminhada de volta pra casa (25 min)" }
      ]
    },
    {
      id: "futebol-noite",
      time: "18:25 – 20:30",
      title: "Preparação + Futebol",
      subtitle: "Banho rápido, deslocamento e treino noturno",
      icon: "⚽",
      color: "#B5502F",
      tasks: [
        { id: "t-banho1", label: "Banho rápido" },
        { id: "t-desloc-quadra", label: "Deslocamento até a quadra" },
        { id: "t-treino-noite", label: "Treino de futebol" },
        { id: "t-volta-casa", label: "Voltar pra casa" }
      ]
    },
    {
      id: "dropshipping",
      time: "20:30 – 21:30",
      title: "Dropshipping",
      subtitle: "Estudo e estruturação da operação internacional",
      icon: "📦",
      color: "#5C7A8A",
      tasks: [
        { id: "t-drop-estudo", label: "Estudo (fornecedores, nicho, mercado)" },
        { id: "t-drop-estrutura", label: "Estruturação prática (o que for aplicável hoje)" }
      ]
    },
    {
      id: "encerramento",
      time: "21:30 – 23:00",
      title: "Jantar & Encerramento",
      subtitle: "Fechar o dia e preparar o sono",
      icon: "🌙",
      color: "#8A7C9C",
      tasks: [
        { id: "t-jantar", label: "Jantar" },
        { id: "t-revisao-dia", label: "Revisar o dia + anotar ideias novas (sem executar)" },
        { id: "t-rotina-dormir", label: "Rotina pra dormir" }
      ]
    }
  ];

  function todayKey() {
    var d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }

  function formatHeaderDate() {
    var d = new Date();
    var s = d.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long" });
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  function loadJSON(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function saveJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      // storage unavailable/full — fail silently, state stays in memory for this session
    }
  }

  var state = {
    customTasks: loadJSON(STORAGE_CUSTOM, {}),
    completed: loadJSON(STORAGE_COMPLETED_PREFIX + todayKey(), {}),
    open: {}
  };
  state.open[DEFAULT_BLOCKS[0].id] = true;

  function allTasksForBlock(block) {
    return block.tasks.concat(state.customTasks[block.id] || []);
  }

  function computeTotals() {
    var total = 0, done = 0;
    DEFAULT_BLOCKS.forEach(function (b) {
      allTasksForBlock(b).forEach(function (t) {
        total++;
        if (state.completed[t.id]) done++;
      });
    });
    return { total: total, done: done };
  }

  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (k) {
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else if (k.indexOf("on") === 0 && typeof attrs[k] === "function") e.addEventListener(k.slice(2), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) {
      if (c) e.appendChild(c);
    });
    return e;
  }

  function icon(name, size) {
    var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("width", size || 18);
    svg.setAttribute("height", size || 18);
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("fill", "none");
    var paths = {
      chevron: '<path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
      check: '<path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
      plus: '<path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
      trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>'
    };
    svg.innerHTML = paths[name] || "";
    return svg;
  }

  function toggleTask(taskId) {
    state.completed[taskId] = !state.completed[taskId];
    saveJSON(STORAGE_COMPLETED_PREFIX + todayKey(), state.completed);
    render();
  }

  function toggleBlock(blockId) {
    state.open[blockId] = !state.open[blockId];
    render();
  }

  function addTask(blockId, inputEl) {
    var label = (inputEl.value || "").trim();
    if (!label) return;
    var newTask = { id: "custom-" + blockId + "-" + Date.now(), label: label };
    state.customTasks[blockId] = (state.customTasks[blockId] || []).concat([newTask]);
    saveJSON(STORAGE_CUSTOM, state.customTasks);
    render();
  }

  function removeTask(blockId, taskId) {
    state.customTasks[blockId] = (state.customTasks[blockId] || []).filter(function (t) { return t.id !== taskId; });
    saveJSON(STORAGE_CUSTOM, state.customTasks);
    delete state.completed[taskId];
    saveJSON(STORAGE_COMPLETED_PREFIX + todayKey(), state.completed);
    render();
  }

  function renderBlock(block) {
    var isOpen = !!state.open[block.id];
    var tasks = allTasksForBlock(block);
    var doneCount = tasks.filter(function (t) { return state.completed[t.id]; }).length;

    var header = el("button", { class: "block-header", onclick: function () { toggleBlock(block.id); } }, [
      el("span", { class: "block-icon", text: block.icon }),
      el("div", { class: "block-title-row" }, [
        el("div", { class: "block-title-line" }, [
          el("span", { class: "block-title", text: block.title }),
          el("span", { class: "block-time display", text: block.time })
        ]),
        el("p", { class: "block-subtitle", text: block.subtitle })
      ]),
      el("div", { class: "block-meta" }, [
        (function () {
          var s = el("span", { class: "block-count display", text: doneCount + "/" + tasks.length });
          s.style.color = block.color;
          return s;
        })(),
        (function () {
          var c = el("span", { class: "chevron" + (isOpen ? " open" : "") }, [icon("chevron", 18)]);
          return c;
        })()
      ])
    ]);

    var body = el("div", { class: "block-body" }, [header]);

    if (isOpen) {
      var taskList = el("div", { class: "task-list" });
      tasks.forEach(function (task) {
        var isCustom = task.id.indexOf("custom-") === 0;
        var done = !!state.completed[task.id];
        var checkbox = el("button", {
          class: "checkbox" + (done ? " done" : ""),
          "aria-label": done ? "Marcar como não concluída" : "Marcar como concluída",
          onclick: function () { toggleTask(task.id); }
        }, done ? [icon("check", 13)] : []);

        var row = el("div", { class: "task-row" }, [
          checkbox,
          el("span", { class: "task-label" + (done ? " done" : ""), text: task.label })
        ]);

        if (isCustom) {
          row.appendChild(el("button", {
            class: "remove-btn",
            "aria-label": "Remover tarefa",
            onclick: function () { removeTask(block.id, task.id); }
          }, [icon("trash", 14)]));
        }
        taskList.appendChild(row);
      });

      var input = el("input", { class: "add-input", type: "text", placeholder: "Adicionar tarefa neste bloco" });
      input.addEventListener("keydown", function (e) {
        if (e.key === "Enter") { addTask(block.id, input); input.value = ""; }
      });
      var addBtn = el("button", { class: "add-btn", "aria-label": "Adicionar tarefa", onclick: function () { addTask(block.id, input); input.value = ""; } }, [icon("plus", 16)]);
      var addRow = el("div", { class: "add-row" }, [input, addBtn]);

      var content = el("div", { class: "block-content" }, [taskList, addRow]);
      body.appendChild(content);
    }

    var rail = el("div", { class: "rail" });
    rail.style.background = block.color;

    return el("div", { class: "block" }, [rail, body]);
  }

  function render() {
    var root = document.getElementById("app");
    root.innerHTML = "";

    var totals = computeTotals();
    var pct = totals.total ? Math.round((totals.done / totals.total) * 100) : 0;

    var wrap = el("div", { class: "wrap" });

    wrap.appendChild(el("div", { class: "eyebrow" }, [
      el("span", { text: "Cronograma diário" })
    ]));
    wrap.appendChild(el("h1", { class: "display", text: formatHeaderDate() }));

    var scoreCard = el("div", { class: "score-card" }, [
      el("div", { class: "score-top" }, [
        el("span", { class: "score-label", text: "Placar do dia" }),
        el("span", { class: "score-value display", text: totals.done + " / " + totals.total })
      ]),
      el("div", { class: "progress-track" }, [
        (function () {
          var fill = el("div", { class: "progress-fill" });
          fill.style.width = pct + "%";
          return fill;
        })()
      ])
    ]);
    wrap.appendChild(scoreCard);

    var blocksEl = el("div", { class: "blocks" });
    DEFAULT_BLOCKS.forEach(function (b) { blocksEl.appendChild(renderBlock(b)); });
    wrap.appendChild(blocksEl);

    wrap.appendChild(el("p", { class: "footer-note", text: "Tarefas concluídas reiniciam a cada novo dia · tarefas adicionadas ficam salvas nos blocos" }));

    root.appendChild(wrap);
  }

  render();

  // Optional install prompt (Android/Chrome) — iOS Safari has no install prompt API,
  // so on iOS the way in is Share > Adicionar à Tela de Início.
  var deferredPrompt = null;
  window.addEventListener("beforeinstallprompt", function (e) {
    e.preventDefault();
    deferredPrompt = e;
  });
})();
