# Cronograma Diário — como colocar no ar

Esse app não precisa de build nem de npm — são só arquivos estáticos (HTML, CSS, JS). Isso significa que dá pra publicar em qualquer serviço de hospedagem gratuita em poucos minutos.

## Opção mais simples: Netlify (arrastar e soltar)

1. Acesse https://app.netlify.com/drop
2. Arraste a pasta inteira `cronograma-pwa` (essa pasta, com todos os arquivos dentro) pra dentro da página
3. Pronto — o Netlify te dá um link público tipo `https://algumnome.netlify.app`
4. Abra esse link no celular, pelo navegador (Chrome no Android ou Safari no iPhone)

## Como instalar no celular depois de publicado

**Android (Chrome):**
- Abra o link → toque nos 3 pontinhos → "Adicionar à tela inicial" ou "Instalar app"

**iPhone (Safari):**
- Abra o link → toque no ícone de compartilhar (quadrado com seta) → "Adicionar à Tela de Início"
- Importante: no iPhone **precisa ser pelo Safari**, outros navegadores não mostram essa opção

Depois de instalado, o app abre em tela cheia, com ícone próprio, e funciona **offline** (os dados ficam salvos no próprio celular).

## Se quiser um link fixo com nome próprio (opcional, mais pra frente)

Dá pra usar um domínio próprio (ex: `cronograma.seunome.com`) tanto no Netlify quanto no Vercel — mas isso é um passo opcional, não é necessário pra instalar e usar o app.

## Estrutura dos arquivos

```
cronograma-pwa/
├── index.html       → estrutura da página
├── style.css        → visual (cores, fontes, layout)
├── app.js           → toda a lógica (blocos, tarefas, salvar dados)
├── manifest.json     → configuração de instalação (nome, ícone, cor)
├── sw.js             → service worker (cache offline)
├── icons/            → ícones do app
└── LEIA-ME.md         → este arquivo
```

## Editando o cronograma depois

Os horários e tarefas padrão de cada bloco estão no início do arquivo `app.js`, dentro de `DEFAULT_BLOCKS`. Dá pra editar horário, título e tarefas ali diretamente. As tarefas que você adiciona pelo próprio app (pelo campo "+") não precisam de edição de código — ficam salvas automaticamente no navegador.
